<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">News</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
          <div class="btn-group mr-2">
            <button type="button"  class="btn btn-sm btn-outline-secondary">Add News</button>
            <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
          </div>
          <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
            <span data-feather="calendar"></span>
            This week
          </button>
        </div>
      </div>
      <h2>Recently</h2>
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th></th>
              <th>Date</th>
              <th>Title</th>
              <th>Details</th>
              <th>Author</th>
            </tr>   
          </thead>
          <tbody>
          <?php
            $SQL = "SELECT * FROM `news` ORDER BY newsID DESC";
		    if($result  = $db_connect->query($SQL)){
			    $rows=$result->fetch_all(MYSQLI_ASSOC);		    	
			    foreach ($rows as $row) {
			    	$date = $row['date'];
			    	$title = $row['title'];
			    	$details = $row['details'];
                    $author = $row['author'];

                    echo 
                    ' 
                    <tr>
                    <td>'.$date.'</td>
                    <td>'.$title.'</td>
                    <td>'.$details.'</td>
                    <td>'.$author.'</td>
                    <td><input type="submit" value="Place"></td>
                  </tr>
                  ';
                }}
        ?>          

        </tbody>
        </table>
      </div>