<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">News</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
          <div class="btn-group mr-2">
            <a href="?page=add_audio" type="button"  class="btn btn-sm btn-outline-secondary">Add Music</a>
          </div>
        </div>
      </div>
      <h2>Recently</h2>
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th></th>
              <th>Date</th>
              <th>Title</th>
              <th>Image</th>
              <th>Details</th>
              <th>Author</th>
            </tr>   
          </thead>
          <tbody>
          <?php
            $SQL = "SELECT * FROM `audio` ORDER BY audio_id DESC";
		    if($result  = $db_connect->query($SQL)){
			    $rows=$result->fetch_all(MYSQLI_ASSOC);		    	
			    foreach ($rows as $row) {
			    	$audioName = $row['audioName'];
			    	$url = $row['url'];
            $author = $row['author'];
            $image = $row['image'];
                    echo 
                    ' 
                    <tr>
                    <td>'.$date.'</td>
                    <td><img src="'.$image.'" width="30px";></td>
                    <td>'.$name.'</td>
                    <td>'.$url.'</td>
                    <td>'.$author.'</td>
                    <td><input type="submit"></td>
                  </tr>
                  ';
                }}
        ?>          

        </tbody>
        </table>
      </div>