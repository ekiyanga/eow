<div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th></th>
              <th>Date</th>
              <th>Title</th>
              <th>Image</th>
              <th>Details</th>
              <th>Author</th>
            </tr>   
          </thead>
          <tbody>
          <?php
          $id = $_GET['id'];
            $SQL = "SELECT * FROM `news` WHERE NewsID = '{$id}'";
		    if($result  = $db_connect->query($SQL)){
			    $rows=$result->fetch_all(MYSQLI_ASSOC);		    	
			    foreach ($rows as $row) {
			    	$date = $row['date'];
			    	$title = $row['title'];
			    	$details = $row['details'];
            $author = $row['author'];
            $image = $row['image'];
                    echo 
                    ' 
                    <tr>
                    <td>'.$date.'</td>
                    <td><img src="'.$image.'" width="30px";></td>
                    <td><input type="text" value="'.$title.'"></td>
                    <td>'.$details.'</td>
                    <td>'.$author.'</td>
                    <td><a href="?page=update_news&&id='.$id.'">Save</a></td>
                    <td><a href="?page=delete_news&&id='.$id.'">Delete</a></td>                    
                  </tr>
                  ';
                }}
        ?>          

        </tbody>
        </table>
      </div>