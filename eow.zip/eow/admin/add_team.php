<?php
if(isset($_POST['add_team'])){
    $title = $_POST['title'];
    $details = $_POST['details'];
    $author = 1;
    $img_url = $site.'/images/'.basename($_FILES["img_url"]["name"]);
    $target_dir = "../images/";
    $target_file = $target_dir . basename($_FILES["img_url"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    
    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["img_url"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
  
  
    // Check if file already exists
    if (file_exists($target_file)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }
  
    // Check file size
    if ($_FILES["img_url"]["size"] > 5000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }
  
    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" && $imageFileType != "JPG" ) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }
  
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
    // if everything is ok, try to upload file
    } else {
    if (move_uploaded_file($_FILES["img_url"]["tmp_name"], $target_file)) {
        $SQL_QUERY = "INSERT INTO `news` (`NewsID`, `date`, `title`, `details`, `image`, `author`) VALUES (NULL, NOW(), '{$title}', '$details', '{$img_url}', '{$author}')";
        $result = $db_connect->query($SQL_QUERY);
        if($result){
            echo "The file ". htmlspecialchars( basename( $_FILES["img_url"]["name"])). " has been uploaded.";
            die("
            <div class='text-center'>
            <br>
            <br>
            <br>
            <h1><i class='fa fa-tick' aria-hidden='true'></i><b>Published</b> </h1>
            <p>See your ticket number on pending menu</p>
            <a href='?page=news' class='btn btn-success btn-lg'>See All</a>
          </div>
          ");
      }else{
        die("failed");
      }        
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
    }
    
}


?>

 
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Team</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
          <div class="btn-group mr-2">
            <a type="button"  class="btn btn-sm btn-outline-secondary" href="?page=add_team">Add New</a>
          </div>
        </div>
      </div>
      <h2>Team Members</h2>
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th></th>
              <th>Picture</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th></th>
            </tr>   
          </thead>
          <tbody>
          <?php
            $SQL = "SELECT * FROM `team` ORDER BY memberID DESC";
        if($result  = $db_connect->query($SQL)){
          $rows=$result->fetch_all(MYSQLI_ASSOC);         
          foreach ($rows as $row) {
            $memberID = $row['memberID'];
            $firstName = $row['firstName'];
            $lastName = $row['lastName'];
            $picture = $row['picture'];

                    echo 
                    ' 
                    <tr>
                    <td></td>
                    <td><img src="images/cover2.jpeg" alt="image1"></td>
                    <td>'.$firstName.'</td>
                    <td>'.$lastName.'</td>
                    <td><input type="submit"></td>
                  </tr>
                  ';
                }}
        ?>          

        </tbody>
        </table>
      </div>