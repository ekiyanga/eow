<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">News</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
          <div class="btn-group mr-2">
            <a href="?page=add_news" type="button"  class="btn btn-sm btn-outline-secondary">Add News</a>
          </div>
        </div>
      </div>
      <h2>Recently</h2>
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th></th>
              <th>Date</th>
              <th>Title</th>
              <th>Author</th>
            </tr>   
          </thead>
          <tbody>
          <?php
            $SQL = "SELECT * FROM `news` ORDER BY newsID DESC";
		    if($result  = $db_connect->query($SQL)){
			    $rows=$result->fetch_all(MYSQLI_ASSOC);		    	
			    foreach ($rows as $row) {
            $id = $row['NewsID'];
			    	$date = $row['date'];
			    	$title = $row['title'];
            $author = $row['author'];
            $image = $row['image'];
                    echo 
                    ' 
                    <tr>
                    <td><img src="'.$image.'" width="30px";></td>                    
                    <td>'.$date.'</td>
                    <td>'.$title.'</td>
                    <td>'.$author.'</td>
                    <td><a href="?page=update_news&&id='.$id.'">Edit</a></td>
                  </tr>
                  ';
                }}
        ?>          

        </tbody>
        </table>
      </div>