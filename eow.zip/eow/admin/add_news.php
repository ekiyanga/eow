<?php
if(isset($_POST['add_news'])){
    $title = $_POST['title'];
    $details = $_POST['details'];
    $author = 1;
    $img_url = $site.'/images/'.basename($_FILES["img_url"]["name"]);
    $target_dir = "../images/";
    $target_file = $target_dir . basename($_FILES["img_url"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    
    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["img_url"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
  
  
    // Check if file already exists
    if (file_exists($target_file)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }
  
    // Check file size
    if ($_FILES["img_url"]["size"] > 5000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }
  
    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" && $imageFileType != "JPG" ) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }
  
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
    // if everything is ok, try to upload file
    } else {
    if (move_uploaded_file($_FILES["img_url"]["tmp_name"], $target_file)) {
        $SQL_QUERY = "INSERT INTO `news` (`NewsID`, `date`, `title`, `details`, `image`, `author`) VALUES (NULL, NOW(), '{$title}', '$details', '{$img_url}', '{$author}')";
        $result = $db_connect->query($SQL_QUERY);
        if($result){
            echo "The file ". htmlspecialchars( basename( $_FILES["img_url"]["name"])). " has been uploaded.";
            die("
            <div class='text-center'>
            <br>
            <br>
            <br>
            <h1><i class='fa fa-tick' aria-hidden='true'></i><b>Published</b> </h1>
            <p>See your ticket number on pending menu</p>
            <a href='?page=news' class='btn btn-success btn-lg'>See All</a>
          </div>
          ");
      }else{
        die("failed");
      }        
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
    }
    
}


?>

 

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">News</h1>
      </div>

    <div class="container">

    <form method="POST" action="" enctype="multipart/form-data">
  	<div class="form-group row">
    	<label for="inputSubject" class="col-sm-2 col-form-label">Title</label>
    	<div class="col-sm-10">
          <input type="text" class="form-control" name="title" required="required">        
    	</div>
  	</div>
  	<div class="form-group row">
    	<label for="inputSubject" class="col-sm-2 col-form-label">Image</label>
    	<div class="col-sm-10">
          <input type="file" class="form-control" name="img_url">        
    	</div>
  	</div>      
    <div class="form-group row">
    	<label for="description" class="col-sm-2 col-form-label">Details</label>
   		<div class="col-sm-10">
   			<textarea class="form-control" rows="3" name="details"></textarea>
   		</div>
  	</div>
  	<hr>
	<div class="form-group row">
    	<div class="col-sm-10">
      		<button type="submit" class="btn btn-success" name="add_news">Send</button>
    	</div>
  	</div>
</form>	


    </div>

