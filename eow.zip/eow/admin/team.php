<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Team</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
          <div class="btn-group mr-2">
            <a type="button"  class="btn btn-sm btn-outline-secondary" href="?page=add_team">Add New</a>
          </div>
        </div>
      </div>
      <h2>Team Members</h2>
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th></th>
              <th>Picture</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th></th>
            </tr>   
          </thead>
          <tbody>
          <?php
            $SQL = "SELECT * FROM `team` ORDER BY memberID DESC";
		    if($result  = $db_connect->query($SQL)){
			    $rows=$result->fetch_all(MYSQLI_ASSOC);		    	
			    foreach ($rows as $row) {
			    	$memberID = $row['memberID'];
			    	$firstName = $row['firstName'];
			    	$lastName = $row['lastName'];
			    	$picture = $row['picture'];

                    echo 
                    ' 
                    <tr>
                    <td></td>
                    <td><img src="images/cover2.jpeg" alt="image1"></td>
                    <td>'.$firstName.'</td>
                    <td>'.$lastName.'</td>
                    <td><input type="submit"></td>
                  </tr>
                  ';
                }}
        ?>          

        </tbody>
        </table>
      </div>