          <?php
          $id = $_GET['id'];
            $SQL = "DELETE FROM `news` WHERE NewsID = '{$id}'";
		    $result  = $db_connect->query($SQL);
            if($result){   	
                echo "deleted";
            }else{
                echo "ERROR";
            }
        ?>          

       