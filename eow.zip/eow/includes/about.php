<div class="jumbotron bg-about">
	<div class="img"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
				<h3>ABOUT US</h3>
            </div>
        </div>
    </div>
</div>


<div class="row">
	<div class="col-md-8">
		<h2>BIO</h2>
		Essence of Worship is a Gospel music band with members from different Churches majored our selves in true values of worship
	</div>
	<div class="col-md-4">
		<h2>MUSIC</h2>
    <iframe scrolling="no" frameborder="0" allowTransparency="true" src="https://www.deezer.com/plugins/player?format=classic&autoplay=false&playlist=true&width=700&height=350&color=EF5466&layout=&size=medium&type=album&id=155158932&app_id=1" width="100%" height="350"></iframe>
	</div>
</div>


	<hr>
	<section>
		<h2>MEET THE TEAM</h2>



  <div class="album py-5 bg-light">
    <div class="container">
        <div class="row">
    
        <?php
          $SQL = "SELECT * FROM `team` ORDER BY memberID ASC LIMIT 9";
          if($result  = $db_connect->query($SQL)){
              $rows=$result->fetch_all(MYSQLI_ASSOC);         
              foreach ($rows as $row) {
                  $memberID = $row['memberID'];
                  $firstName = $row['firstName'];
                  $lastName = $row['lastName'];
                  $picture = $row['picture'];
                  $occupation = $row['occupation'];

                  echo 
                    ' 
                    <!-- Team Member 1 -->
                    <div class="col-xl-4 col-md-6 mb-4">
                      <div class="card border-0 shadow">
                        <img src="'.$picture.'" class="card-img-top" alt="'.$firstName.' '.$lastName.'">
                        <div class="card-body text-center">
                          <h3 class="card-title mb-0">'.$firstName.' '.$lastName.'</h3>
                          <div class="card-text">'.$occupation.'</div>
                          <div class="card-text">

                          <ul class="nav social-top">
                          <li class="nav-item">
                            <a class="nav-link" href="https://www.instagram.com/essenceofworshipministries/" target="_blank"><i class="fa fa-instagram fa-lg" aria-hidden="true"></i></a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="https://web.facebook.com/EssenceOfWorshipMinistries" target="_blank"><i class="fa fa-facebook-square fa-lg" aria-hidden="true"></i></a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="https://twitter.com/eowministriestz" target="_blank"><i class="fa fa-twitter fa-lg" aria-hidden="true"></i></a>
                          </li>
                        </ul>                          
                          </div>
                        </div>
                      </div>
                    </div>
                          ';
              }
            }
        ?>       
  </div>
  <!-- /.row -->


<div class="row">
	     <div class="col-md-12 mb-4 text-center">
      	<strong><a href="?page=team">+ See More</a></strong>
    </div>
</div>


    </div>
  </div>


	</section>