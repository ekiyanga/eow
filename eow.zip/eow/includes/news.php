<div class="jumbotron bg-news">
  <div class="img"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
				<h3>NEWS</h3>
            </div>
        </div>
    </div>
</div>
<br>
<div class="row">
	<div class="col-md-8">
		<h2>NEWS</h2>
    	<img src="images/newalbum.jpg" width="100%">
      

	</div>
	<br>
	<div class="col-md-4">
		<h2 class="featurette-heading">MUSIC</h2>
    <iframe scrolling="no" frameborder="0" allowTransparency="true" src="https://www.deezer.com/plugins/player?format=classic&autoplay=false&playlist=true&width=700&height=350&color=EF5466&layout=&size=medium&type=album&id=155158932&app_id=1" width="100%" height="350"></iframe>
	</div>
</div>
<br>
 <!--
  <div class="row mb-2">
  <?php
      $SQL = "SELECT * FROM `news` ORDER BY newsID DESC";
      if($result  = $db_connect->query($SQL)){
          $rows=$result->fetch_all(MYSQLI_ASSOC);         
          foreach ($rows as $row) {
            $id = $row['NewsID'];
            $date = $row['date'];
            $title = $row['title'];
            $details = substr($row['details'], 0, 100);
            $image = $row['image'];

            echo 
                ' 
                <div class="col-md-6">
                  <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                    <div class="col p-4 d-flex flex-column position-static">
                      <h3 class="mb-0">'.$title.'</h3>
                      <div class="mb-1 text-muted">'.$date.'</div>
                      <p class="mb-auto">'.$details.' . . .</p>
                      <a href="?page=content&id='.$id.'" class="stretched-link">Continue Reading</a>
                    </div>
                    <div class="col-auto d-none d-lg-block">
                      <img class="img-fluid bd-placeholder-img" width="200" height="250" src="'.$image.'" alt="'.$title.'">
                  </div>
                  </div>
                </div>
                ';
          }
      }
     ?>   
  </div>  -->