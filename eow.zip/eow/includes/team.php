<section>
		<h2>MEET THE TEAM</h2>



  <div class="album py-5 bg-light">
    <div class="container">
        <div class="row">
    
        <?php
          $SQL = "SELECT * FROM `team` ORDER BY memberID ASC";
          if($result  = $db_connect->query($SQL)){
              $rows=$result->fetch_all(MYSQLI_ASSOC);         
              foreach ($rows as $row) {
                  $memberID = $row['memberID'];
                  $firstName = $row['firstName'];
                  $lastName = $row['lastName'];
                  $picture = $row['picture'];
                  $occupation = $row['occupation'];

                  echo 
                    ' 
                    <!-- Team Member 1 -->
                    <div class="col-xl-4 col-md-6 mb-4">
                      <div class="card border-0 shadow">
                        <img src="'.$picture.'" class="card-img-top" alt="'.$firstName.' '.$lastName.'">
                        <div class="card-body text-center">
                          <h3 class="card-title mb-0">'.$firstName.' '.$lastName.'</h3>
                          <div class="card-text">'.$occupation.'</div>
                          <div class="card-text">
                          
                  <ul class="nav">
                  <li class="nav-item">
                    <a class="nav-link" href="https://www.instagram.com/essenceofworshipministries/" target="_blank"><i class="fa fa-instagram fa-lg" aria-hidden="true"></i></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="https://www.youtube.com/channel/UCPMLZ3CqV_7H-gHSsNZBJsw" target="_blank"><i class="fa fa-youtube-play fa-lg" aria-hidden="true"></i></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="https://web.facebook.com/EssenceOfWorshipMinistries" target="_blank"><i class="fa fa-facebook-square fa-lg" aria-hidden="true"></i></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="https://twitter.com/eowministriestz" target="_blank"><i class="fa fa-twitter fa-lg" aria-hidden="true"></i></a>
                  </li>
                </ul>
                          
                          </div>
                        </div>
                      </div>
                    </div>
                          ';
              }
            }
        ?>       

  

  </div>
  <!-- /.row -->
    </div>
  </div>


	</section>