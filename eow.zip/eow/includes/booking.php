<div class="jumbotron bg-news">
  <div class="img"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h3>BOOKING</h3>
            </div>
        </div>
    </div>
</div>