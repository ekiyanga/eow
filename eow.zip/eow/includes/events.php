<div class="jumbotron bg-event">
  <div class="img"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h3>EVENTS AND TOUR</h3>
            </div>
        </div>
    </div>
</div>

  <div class="album py-5 bg-light">
    <div class="container">

      <div class="card-deck">
 <?php
      $SQL = "SELECT * FROM `events` ORDER BY event_id DESC";
      if($result  = $db_connect->query($SQL)){
          $rows=$result->fetch_all(MYSQLI_ASSOC);         
          foreach ($rows as $row) {
            $id = $row['event_id'];
            $date = $row['date'];
            $eventName = $row['eventName'];
            $description = $row['description'];
            $venue = $row['venue'];
            $image = $row['image'];

            echo '

      
        <div class="card">
          <img class="card-img-top" src="'.$image.'" alt="'.$eventName.'">
          <div class="card-body">
            <h3 class="card-title"> '.$eventName.' </h3>
            <p class="card-text"><i class=" fa fa-map-marker"></i> '.$venue.'</p>
            <p class="card-text"><i class=" fa fa-calendar"></i> '.$date.'</p>
          </div>
        </div> 
          ';

        }
    }
    ?>
      </div>
    </div>
  </div>