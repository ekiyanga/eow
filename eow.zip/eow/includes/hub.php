<div class="jumbotron bg-news">
  <div class="img"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h3>ESSENCE OF WORSHIP HUB</h3>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-4">
        <p>venue for practice worship leaders workshops
            <ul>
                <li>Music Classes</li>   
                <li>Guitars</li>
            </ul>
            <a href="?page=contact">CONTACT US</a>
        </p>
    </div>
    <div class="col-md-8">
    
    </div>




</div>