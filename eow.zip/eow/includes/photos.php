<div class="jumbotron bg-news">
  <div class="img"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h3>PHOTOS</h3>
            </div>
        </div>
    </div>
</div>

<h2>GALLERY</h2>
<p><b>"Jeremiah 20:13"</b> Sing to the LORD! Give praise to the LORD! He rescues the life of the needy from the hands of the wicked.</p>


<!-- Grid row -->
<div class="row">

<?php
    $SQL = "SELECT * FROM `images`";
      if($result  = $db_connect->query($SQL)){
          $rows=$result->fetch_all(MYSQLI_ASSOC);         
          foreach ($rows as $row) {
            $id = $row['id'];
            $url = $row['url'];
            
            echo '
  <!-- Grid column -->
  <div class="col-lg-3 col-md-6 mb-4">

    <!--Modal: Name-->
    <div class="modal fade" id="modal'.$id.'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">

        <!--Content-->
        <div class="modal-content">

          <!--Body-->
          <div class="modal-body mb-0 p-0">

          <img class="img-fluid z-depth-1" src="'.$url.'" alt="'.$url.'">

          </div>

          <!--Footer-->
          <div class="modal-footer d-block d-md-flex justify-content-center">
            <span class="mr-4">Listen Audio (MP3)</span>
            <div class="social-links">
  			              <a href="https://open.spotify.com/artist/08DEnWbiZl4cLFGUjNzR39" target="_blank"><i class="fa fa-spotify fa-spotify-color fa-2x" aria-hidden="true"></i></a>
                      <a href="https://www.deezer.com/en/artist/98042182" target="_blank"><i class="fa fa-music fa-twitter-color fa-2x" aria-hidden="true"></i></a>
  		</div>

            <button type="button" class="btn btn-outline-primary btn-rounded btn-md ml-4" data-dismiss="modal">Close</button>

          </div>

        </div>
        <!--/.Content-->

      </div>
    </div>
    <!--Modal: Name-->

    <a><img class="img-fluid z-depth-1" src="'.$url.'" alt="video"
        data-toggle="modal" data-target="#modal'.$id.'"></a>
       

  </div>
  <!-- Grid column -->
';
}}
?>


</div>
<!-- Grid row -->

         