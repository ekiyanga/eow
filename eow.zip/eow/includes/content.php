<?php
$id = $_GET['id'];
$SQL = "SELECT * FROM `news` WHERE NewsID = '{$id}' ";
if($result  = $db_connect->query($SQL)){
    $rows=$result->fetch_all(MYSQLI_ASSOC);         
    foreach ($rows as $row) {
      $date = $row['date'];
      $title = $row['title'];
      $details = $row['details'];
      $image = $row['image'];

      echo '
<div class="row">
  <div class="col-md-12">
    <h2>NEWS</h2>
      <img src="'.$image.'" width="100%">
      </div>

  </div>

        <div class="row mb-2">
          <div class="col-md-12">
            <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
              <div class="col p-4 d-flex flex-column position-static">
                <h3 class="mb-0">'.$title.'</h3>
                <div class="mb-1 text-muted">'.$date.'</div>
                <p style="color:black" class="card-text mb-auto">'.$details.'</p>
              </div>
            </div>
          </div>
        </div>
      ';
    }
}
?>