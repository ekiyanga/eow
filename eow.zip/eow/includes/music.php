<div class="container">
<div class="jumbotron bg-news">
  <div class="img"></div>
        <div class="row">
            <div class="col-lg-12">
                <h3>MUSIC</h3>
            </div>
        </div>
</div>
<div class="row">
        <div class="col-md-7">
        <?php
            $SQL = "SELECT * FROM `iframe` ORDER BY iframeID DESC LIMIT 1";
            if($result  = $db_connect->query($SQL)){
                $rows=$result->fetch_all(MYSQLI_ASSOC);         
                foreach ($rows as $row) {
                  $name = $row['name'];
                  $iframe = $row['iframe'];

                  echo 
                      '          
                      <h2 class="featurette-heading">'.$name.'</h2>
                      <div class="embed-responsive embed-responsive-16by9">
                         '.$iframe.'
                      </div>
                      ';
                  echo '</div>';
                }
            }

        ?>
        <div class="col-md-5">
            <h2 class="featurette-heading">MUSIC</h2>
                <iframe scrolling="no" frameborder="0" allowTransparency="true" src="https://www.deezer.com/plugins/player?format=classic&autoplay=false&playlist=true&width=700&height=350&color=EF5466&layout=&size=medium&type=album&id=155158932&app_id=1" width="100%" height="350"></iframe>
            

        </div>
      </div>
    </div>
<hr>



<!-- Grid row -->
<div class="row">

<?php
    $SQL = "SELECT * FROM `music`";
      if($result  = $db_connect->query($SQL)){
          $rows=$result->fetch_all(MYSQLI_ASSOC);         
          foreach ($rows as $row) {
            $id = $row['id'];
            $name = $row['name'];
            $iframe = $row['iframe'];   
            $img = $row['img'];                        
            
            echo '

  <!-- Grid column -->
  <div class="col-lg-3 col-md-6 mb-4">

    <!--Modal: Name-->
    <div class="modal fade" id="modal'.$id.'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">

        <!--Content-->
        <div class="modal-content">

          <!--Body-->
          <div class="modal-body mb-0 p-0">

            <div class="embed-responsive embed-responsive-16by9 z-depth-1-half">
            <iframe width="560" height="315" src="'.$iframe.'" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>

          </div>

          <!--Footer-->
          <div class="modal-footer d-block d-md-flex justify-content-center">
            <span class="mr-4">Listen Audio (MP3)</span>
            <div class="social-links">
  			              <a href="https://open.spotify.com/artist/08DEnWbiZl4cLFGUjNzR39" target="_blank"><i class="fa fa-spotify fa-spotify-color fa-2x" aria-hidden="true"></i></a>
                      <a href="https://www.deezer.com/en/artist/98042182" target="_blank"><i class="fa fa-music fa-twitter-color fa-2x" aria-hidden="true"></i></a>
  		</div>

            <button type="button" class="btn btn-outline-primary btn-rounded btn-md ml-4" data-dismiss="modal">Close</button>

          </div>

        </div>
        <!--/.Content-->

      </div>
    </div>
    <!--Modal: Name-->

    <a><img class="img-fluid z-depth-1" src="'.$img.'" alt="'.$name.'"
        data-toggle="modal" data-target="#modal'.$id.'"></a>
        <p>'.$name.'</p>

  </div>
  <!-- Grid column -->
';
          }}
          ?>
</div>
<!-- Grid row -->