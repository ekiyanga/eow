<?php
$db_name = "eow_db";
$server = "localhost";
$db_user = "root";
$db_password = "";
$system_name = "eow";
$site = "http://".$server."/".$system_name;

$db_connect = new mysqli($server, $db_user, $db_password, $db_name);
if($db_connect->connect_error){
	die("<h1>SYSTEM UNAVAILABLE, CONTACT SYSTEM ADMINISTRATOR</h1>");
}

?>

<?
/*
INSERT INTO `team` 
(`memberID`, `firstName`, `lastName`, `picture`, `occupation`, `description`, `facebook`, `instagram`, `twitter`, `createdBy`) 
VALUES (NULL, '{$firstName}', '{$lastName}', '{$picture}', '{$occupation}', '{$description}', '{$facebook}', '{$instagram}', '{$twitter}, '{$createdBy}')


*/