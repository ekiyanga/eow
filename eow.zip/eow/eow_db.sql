-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2020 at 08:14 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eow_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `audio`
--

CREATE TABLE `audio` (
  `audio_id` int(11) NOT NULL,
  `audioName` varchar(100) NOT NULL,
  `url` text NOT NULL,
  `picture` varchar(100) NOT NULL,
  `author` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE `authors` (
  `authorID` int(11) NOT NULL,
  `firstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `phoneNumber` varchar(10) DEFAULT NULL,
  `role` int(1) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `dateCreated` date NOT NULL,
  `active` int(1) NOT NULL,
  `profilePicture` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='A table to reserve details of authors';

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`authorID`, `firstName`, `LastName`, `email`, `password`, `phoneNumber`, `role`, `createdBy`, `dateCreated`, `active`, `profilePicture`) VALUES
(1, 'Eliseth', 'Kiyanga', 'elispeke@gmail.com', '123456', NULL, 2, 0, '2020-09-02', 1, NULL),
(2, 'Eliseth', 'Kiyanga', 'elispeke@gmail.com', '123456', NULL, 2, 1, '2020-09-02', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_id` int(11) NOT NULL,
  `eventName` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `venue` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `author` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_id`, `eventName`, `description`, `image`, `venue`, `date`, `author`) VALUES
(1, 'Bwana Unatawala', 'Hil ni tamasha la kil aisksi ', 'http://localhost/eow/images/event2.jpg', 'Arusha', '2020-10-16', 'eliseth.kiyanga'),
(2, 'Bwana Unatawala 2', 'Hil ni tamasha la kil aisksi ', 'http://localhost/eow/images/event3.jpg', 'Dodoma', '2020-10-16', 'eliseth.kiyanga'),
(3, 'Bwana Unatawala 3', 'Hil ni tamasha la kil aisksi ', 'http://localhost/eow/images/event1.jpg', 'Mwanza', '2020-10-16', 'eliseth.kiyanga'),
(4, 'Bwana Unatawala 4', 'Hil ni tamasha la kil aisksi ', 'http://localhost/eow/images/event2.jpg', 'Mwanza', '2020-10-16', 'eliseth.kiyanga');

-- --------------------------------------------------------

--
-- Table structure for table `iframe`
--

CREATE TABLE `iframe` (
  `iframeID` int(11) NOT NULL,
  `iframe` text NOT NULL,
  `name` varchar(200) NOT NULL,
  `createdBy` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iframe`
--

INSERT INTO `iframe` (`iframeID`, `iframe`, `name`, `createdBy`) VALUES
(1, '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/1AvYosijjLY?start=16\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'Essence of Worship ft Paul Clement - Hutimiza Maagano', 1);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `url` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `url`) VALUES
(1, 'images/gallery/pic1.jpg'),
(10, 'images/gallery/pic10.jpg'),
(2, 'images/gallery/pic2.jpg'),
(3, 'images/gallery/pic3.jpg'),
(4, 'images/gallery/pic4.jpg'),
(5, 'images/gallery/pic5.jpg'),
(6, 'images/gallery/pic6.jpg'),
(7, 'images/gallery/pic7.jpg'),
(8, 'images/gallery/pic8.jpg'),
(9, 'images/gallery/pic9.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `music`
--

CREATE TABLE `music` (
  `id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `iframe` text DEFAULT NULL,
  `img` varchar(200) NOT NULL,
  `author` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `music`
--

INSERT INTO `music` (`id`, `name`, `iframe`, `img`, `author`) VALUES
(1, 'Bwana Unatawala', 'https://www.youtube.com/embed/vikYFRSODFA', 'images/bwanaunatawala.jpg', 'eliseth.kiyanga'),
(2, 'Hutimiza Maagano ft Paul Clement', 'https://www.youtube.com/embed/1AvYosijjLY', 'images/gallery/pic4.jpg', 'eliseth.kiyanga');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `NewsID` int(11) NOT NULL,
  `date` date NOT NULL,
  `title` varchar(200) NOT NULL,
  `details` text DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `author` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`NewsID`, `date`, `title`, `details`, `image`, `author`) VALUES
(9, '2020-09-30', 'Essence of worship in Arusha', '', 'http://localhost/eow/images/Screenshot from 2020-01-25 05-16-27.png', 1),
(11, '2020-10-26', 'Essence of worship in Dodoma', 'essence wameweza kufanya hicivsas', 'http://localhost/eow/images/news.jpg', 1),
(13, '2020-10-28', 'Bwana Unatawala', 'This song uplifts my soul my baby loves this song to blue and moon she really loves you guys and she is only few months old she sings with you hadi analala.....akisikia huu wimbo she jumps up ready to sing with you soon she needs to join you guys....lots of love from \r\n', 'http://localhost/eow/images/testi.jpeg', 1),
(14, '2020-10-28', 'New news', 'This song uplifts my soul my baby loves this song to blue and moon she really loves you guys and she is only few months old she sings with you hadi analala.....akisikia huu wimbo she jumps up ready to sing with you soon she needs to join you guys....lots of love from This song uplifts my soul my baby loves this song to blue and moon she really loves you guys and she is only few months old she sings with you hadi analala.....akisikia huu wimbo she jumps up ready to sing with you soon she needs to join you guys....lots of love from This song uplifts my soul my baby loves this song to blue and moon she really loves you guys and she is only few months old she sings with you hadi analala.....akisikia huu wimbo she jumps up ready to sing with you soon she needs to join you guys....lots of love from This song uplifts my soul my baby loves this song to blue and moon she really loves you guys and she is only few months old she sings with you hadi analala.....akisikia huu wimbo she jumps up ready to sing with you soon she needs to join you guys....lots of love from This song uplifts my soul my baby loves this song to blue and moon she really loves you guys and she is only few months old she sings with you hadi analala.....akisikia huu wimbo she jumps up ready to sing with you soon she needs to join you guys....lots of love from This song uplifts my soul my baby loves this song to blue and moon she really loves you guys and she is only few months old she sings with you hadi analala.....akisikia huu wimbo she jumps up ready to sing with you soon she needs to join you guys....lots of love from This song uplifts my soul my baby loves this song to blue and moon she really loves you guys and she is only few months old she sings with you hadi analala.....akisikia huu wimbo she jumps up ready to sing with you soon she needs to join you guys....lots of love from This song uplifts my soul my baby loves this song to blue and moon she really loves you guys and she is only few months old she sings with you hadi analala.....akisikia huu wimbo she jumps up ready to sing with you soon she needs to join you guys....lots of love from This song uplifts my soul my baby loves this song to blue and moon she really loves you guys and she is only few months old she sings with you hadi analala.....akisikia huu wimbo she jumps up ready to sing with you soon she needs to join you guys....lots of love from This song uplifts my soul my baby loves this song to blue and moon she really loves you guys and she is only few months old she sings with you hadi analala.....akisikia huu wimbo she jumps up ready to sing with you soon she needs to join you guys....lots of love from ', 'http://localhost/eow/images/test2.jpeg', 1),
(15, '2020-10-28', 'New news', 'This song uplifts my soul my baby loves this song to blue and moon she really loves you guys and she is only few months old she sings with you hadi analala.....akisikia huu wimbo she jumps up ready to sing with you soon she needs to join you \r\n       guys....lots of love from This song uplifts my soul my baby loves this song to blue and moon she really loves you guys and she is only few months old she sings with you hadi analala.....akisikia huu wimbo she jumps up ready to sing with you soon she needs to join you guys....lots of love from This song uplifts my soul my baby loves this song to blue and moon she really loves you guys.\r\n                        and she is only few months old she sings with you hadi analala.....akisikia huu wimbo she jumps up ready to sing with you soon she needs to join you guys....lots of love from This song uplifts my soul my baby loves this song to blue and moon she really loves you guys and she is only few months old she sings with you hadi analala.....akisikia huu wimbo she jumps up ready to sing with you soon she needs to join you guys....lots of love from This song uplifts my soul my baby loves this song to blue and moon she really loves you guys and she is only few months old she sings with you hadi analala.....akisikia huu wimbo she jumps up ready to sing with you soon she needs to join you guys....lots of love from This song uplifts my soul my baby loves this song to blue and moon she really loves you guys and she is only few months old she sings with you', 'http://localhost/eow/images/test3.jpeg', 1),
(17, '2020-11-23', 'New UDSM Logo', 'This logo belongs tp UDSM', 'http://localhost/eow/images/Udom - Social Hostel.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `slideshow`
--

CREATE TABLE `slideshow` (
  `image` varchar(200) NOT NULL,
  `link` varchar(200) DEFAULT NULL,
  `author` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slideshow`
--

INSERT INTO `slideshow` (`image`, `link`, `author`) VALUES
('images/newalbum.jpg', '#', 1);

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `memberID` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `picture` varchar(200) DEFAULT NULL,
  `occupation` varchar(200) DEFAULT NULL,
  `facebook` varchar(200) DEFAULT NULL,
  `instagram` varchar(200) DEFAULT NULL,
  `twitter` varchar(200) DEFAULT NULL,
  `createdBy` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`memberID`, `firstName`, `lastName`, `picture`, `occupation`, `facebook`, `instagram`, `twitter`, `createdBy`) VALUES
(1, 'Gwamaka', 'Mwakalinga', 'images/team/gwamakamwakalinga.jpg', 'Founder and Chief Executive Officer', 'facebook.com', 'instagram.com', 'twiiter.com', '2020-09-29'),
(2, 'Nuru', 'Gwamaka', 'images/team/nurugwamaka.jpg', 'Assitant Chief Executive Officer | Prayer Coordinator', 'facebook.com', 'instagram.com', 'twiiter.com', '2020-09-29'),
(3, 'Elizabeth', 'Tsere', 'images/team/elizabethtsere.jpg', 'Administrator | Soprano', NULL, NULL, NULL, '2020-09-03'),
(4, 'Joshua', 'Charles', 'images/team/joshuacharles.jpg', 'Music Director | Lead First Keys', 'facebook.com', 'instagram.com', 'twiiter.com', '2020-09-29'),
(5, 'Dina', 'Hango', 'images/team/dinahango.jpg', 'Administrator | Alto', 'facebook.com', 'instagram.com', 'twiiter.com', '2020-09-29'),
(6, 'Dorcas', 'Michael', 'images/team/dorcasmichael.jpg', 'Soprano', NULL, NULL, NULL, '2020-09-03'),
(7, 'Emmanuel', 'Benard', 'images/team/emmanuelbenard.jpg', 'Tenor', 'facebook.com', 'instagram.com', 'twiiter.com', '2020-09-29'),
(8, 'Estheria', 'Masele', 'images/team/estheriamasele.jpg', 'Treasurer | Alto', 'facebook.com', 'instagram.com', 'twiiter.com', '2020-09-29'),
(9, 'Ezra', 'Shayo', 'images/team/ezrashayo.jpg', 'Tenor', 'facebook.com', 'instagram.com', 'twiiter.com', '2020-09-29'),
(10, 'Getrude ', 'Siza', 'images/team/getrudesiza.jpg', 'Soprano', 'facebook.com', 'instagram.com', 'twiiter.com', '2020-09-29'),
(67, 'Jescar', 'Paul', 'images/team/jescarpaul.jpg', 'Media | Soprano', 'facebook.com', 'instagram.com', 'twiiter.com', '2020-09-29'),
(68, 'James', 'Mngodo', 'images/team/jamesmngodo.jpg', 'Second Keys', 'facebook.com', 'instagram.com', 'twiiter.com', '2020-09-29'),
(69, 'Kepha', 'Mndeme', 'images/team/kephamndeme.jpg', 'Music Director | Sequencer and Programmings', 'facebook.com', 'instagram.com', 'twiiter.com', '2020-09-29'),
(70, 'Andrew', 'Michael', 'images/team/andrewmichael.jpg', 'Lead Guitar', 'facebook.com', 'instagram.com', 'twiiter.com', '2020-09-29'),
(71, 'Eric', 'Kashoma', 'images/team/erickashoma.jpg', 'Tenor', 'facebook.com', 'instagram.com', 'twiiter.com', '2020-09-29'),
(72, 'Jessica', 'Williams', 'images/team/jessicawilliams.jpg', 'Stylist | Alto', 'facebook.com', 'instagram.com', 'twiiter.com', '2020-09-29'),
(73, 'Neema', 'Kiyogomo', 'images/team/neemakiyogomo.jpg', 'Administrator | Alto', 'facebook.com', 'instagram.com', 'twiiter.com', '2020-09-29'),
(74, 'Victoria', 'Napiya', 'images/team/victorianapiya.jpg', 'Choreographer | Alto', 'facebook.com', 'instagram.com', 'twiiter.com', '2020-09-29'),
(75, 'Witness', 'Spear', 'images/team/witnessspear.jpg', 'Soprano', 'facebook.com', 'instagram.com', 'twiiter.com', '2020-09-29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audio`
--
ALTER TABLE `audio`
  ADD PRIMARY KEY (`audio_id`);

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`authorID`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `iframe`
--
ALTER TABLE `iframe`
  ADD PRIMARY KEY (`iframeID`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`);

--
-- Indexes for table `music`
--
ALTER TABLE `music`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`NewsID`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`memberID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audio`
--
ALTER TABLE `audio`
  MODIFY `audio_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `authorID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `iframe`
--
ALTER TABLE `iframe`
  MODIFY `iframeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `music`
--
ALTER TABLE `music`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `NewsID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `memberID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
