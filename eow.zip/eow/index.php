<?php

/*
	*  Project Name: Essence of Worship Ministries Official Website
	*  Client: Essence of Worship 
	*  Developer: elisethkiyanga.com
	*   
	*
*/

//require connection;
require 'connection/connect.php';

//include template file
require 'includes/template.php';


?>